function display(CPD)

disp(struct(CPD));
